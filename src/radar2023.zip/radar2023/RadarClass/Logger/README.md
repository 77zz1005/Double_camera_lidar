# Copyright(C),2022-2023,沈阳航空航天大学T-UP战队 All Rights Reserved

# Logger: 日志模块

## 文件结构

├── include
│   └── Logger.h		//头文件
└── src
     └── Logger.cpp		//cpp文件

## 简介

基于spdlog的日志模块，单次注册后可全局根据命名获取调用
