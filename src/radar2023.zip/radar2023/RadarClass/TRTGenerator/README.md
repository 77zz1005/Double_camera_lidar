# onnx2tensorrt_cpp
通用onnx->engine转换器，显式batch适用
